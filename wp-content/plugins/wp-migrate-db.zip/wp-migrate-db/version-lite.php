<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db']['version'] = '2.4.1';
